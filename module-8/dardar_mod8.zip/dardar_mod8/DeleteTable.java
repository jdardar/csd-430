import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/*
 * DeleteTable.java
 *
 * Deletes the students table from the csd430 database.
 * This file is included as required source code.
 * Do not run it before submitting because it will remove the table.
 */
public class DeleteTable {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/csd430";
        String user = "root";
        String password = "addimae69";

        String sql = "DROP TABLE IF EXISTS students";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection connection =
                DriverManager.getConnection(url, user, password);

            Statement statement =
                connection.createStatement();

            statement.executeUpdate(sql);

            System.out.println(
                "The students table was deleted successfully."
            );

            statement.close();
            connection.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}