<%@ page import="java.sql.*" %>
<%@ page import="com.dardar.StudentBean" %>

<%
    /*
     * updateStudent.jsp
     *
     * Updates the selected student record and then retrieves
     * the updated record for display in an HTML table.
     */

    request.setCharacterEncoding("UTF-8");

    StudentBean student = new StudentBean();

    String errorMessage = null;
    boolean updateSuccessful = false;

    if (!"POST".equalsIgnoreCase(request.getMethod())) {

        errorMessage =
            "This page must be opened by submitting "
            + "the student update form.";

    } else {

        try {
            student.setId(
                Integer.parseInt(
                    request.getParameter("studentId")
                )
            );

            student.setFirstName(
                request.getParameter("firstName")
            );

            student.setLastName(
                request.getParameter("lastName")
            );

            student.setEmail(
                request.getParameter("email")
            );

            student.setCourse(
                request.getParameter("course")
            );

            student.setGrade(
                request.getParameter("grade")
            );

            String url =
                "jdbc:mysql://localhost:3306/csd430"
                + "?useSSL=false"
                + "&allowPublicKeyRetrieval=true"
                + "&serverTimezone=UTC";

            String dbUser = "root";
            String dbPassword =
                "addimae69";

            String updateSql =
                "UPDATE students SET "
                + "first_name = ?, "
                + "last_name = ?, "
                + "email = ?, "
                + "course = ?, "
                + "grade = ? "
                + "WHERE id = ?";

            String selectSql =
                "SELECT id, first_name, last_name, "
                + "email, course, grade "
                + "FROM students "
                + "WHERE id = ?";

            Class.forName("com.mysql.cj.jdbc.Driver");

            try (
                Connection connection =
                    DriverManager.getConnection(
                        url,
                        dbUser,
                        dbPassword
                    )
            ) {

                try (
                    PreparedStatement updateStatement =
                        connection.prepareStatement(updateSql)
                ) {

                    updateStatement.setString(
                        1,
                        student.getFirstName()
                    );

                    updateStatement.setString(
                        2,
                        student.getLastName()
                    );

                    updateStatement.setString(
                        3,
                        student.getEmail()
                    );

                    updateStatement.setString(
                        4,
                        student.getCourse()
                    );

                    updateStatement.setString(
                        5,
                        student.getGrade()
                    );

                    updateStatement.setInt(
                        6,
                        student.getId()
                    );

                    int rowsUpdated =
                        updateStatement.executeUpdate();

                    if (rowsUpdated != 1) {
                        throw new SQLException(
                            "The selected student record "
                            + "was not updated."
                        );
                    }
                }

                try (
                    PreparedStatement selectStatement =
                        connection.prepareStatement(selectSql)
                ) {

                    selectStatement.setInt(
                        1,
                        student.getId()
                    );

                    try (
                        ResultSet resultSet =
                            selectStatement.executeQuery()
                    ) {

                        if (resultSet.next()) {

                            student.setId(
                                resultSet.getInt("id")
                            );

                            student.setFirstName(
                                resultSet.getString("first_name")
                            );

                            student.setLastName(
                                resultSet.getString("last_name")
                            );

                            student.setEmail(
                                resultSet.getString("email")
                            );

                            student.setCourse(
                                resultSet.getString("course")
                            );

                            student.setGrade(
                                resultSet.getString("grade")
                            );

                            updateSuccessful = true;

                        } else {

                            throw new SQLException(
                                "The updated student record "
                                + "could not be retrieved."
                            );
                        }
                    }
                }
            }

        } catch (Exception exception) {

            errorMessage = exception.getMessage();
        }
    }
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Updated Student Record</title>

    <link rel="stylesheet" href="styles.css">
</head>

<body>

<header>
    <h1>Updated Student Record</h1>

    <p>
        MySQL database update results
    </p>
</header>

<nav>
    <a href="index.jsp">Create and View Records</a>
    <a href="selectStudent.jsp">Update a Record</a>
</nav>

<main class="container">

    <% if (errorMessage != null) { %>

        <div class="error">
            <strong>Update error:</strong>
            <%= errorMessage %>
        </div>

        <a
            class="button"
            href="selectStudent.jsp"
        >
            Return to Student Selection
        </a>

    <% } %>

    <% if (updateSuccessful) { %>

        <div class="success">
            The student record was updated successfully.
        </div>

        <h2>Updated Record</h2>

        <div class="table-wrapper">

            <table>

                <thead>
                    <tr>
                        <th>ID<br>INT</th>
                        <th>First Name<br>VARCHAR(50)</th>
                        <th>Last Name<br>VARCHAR(50)</th>
                        <th>Email<br>VARCHAR(100)</th>
                        <th>Course<br>VARCHAR(50)</th>
                        <th>Grade<br>VARCHAR(10)</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>
                            <%= student.getId() %>
                        </td>

                        <td>
                            <%= student.getFirstName() %>
                        </td>

                        <td>
                            <%= student.getLastName() %>
                        </td>

                        <td>
                            <%= student.getEmail() %>
                        </td>

                        <td>
                            <%= student.getCourse() %>
                        </td>

                        <td>
                            <%= student.getGrade() %>
                        </td>
                    </tr>
                </tbody>

            </table>

        </div>

        <p>
            <a
                class="button"
                href="selectStudent.jsp"
            >
                Update Another Record
            </a>

            <a
                class="button"
                href="index.jsp"
            >
                View All Records
            </a>
        </p>

    <% } %>

</main>

<footer>
    Jordan Dardar | CSD430 Server Side Development
</footer>

</body>
</html>