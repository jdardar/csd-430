package com.dardar;

/*
 * StudentBean.java
 *
 * JavaBean representing one record from the students table.
 * The bean contains private fields, a no-argument constructor,
 * and public getter and setter methods.
 */
public class StudentBean {

    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String course;
    private String grade;

    public StudentBean() {
    }

    public StudentBean(
            int id,
            String firstName,
            String lastName,
            String email,
            String course,
            String grade) {

        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.course = course;
        this.grade = grade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
}