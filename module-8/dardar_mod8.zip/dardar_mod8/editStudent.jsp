<%@ page import="java.sql.*" %>
<%@ page import="com.dardar.StudentBean" %>

<%
    /*
     * editStudent.jsp
     *
     * Retrieves the selected student record and displays
     * every field in an HTML update form.
     */

    StudentBean student = null;
    String errorMessage = null;

    String studentIdParameter =
        request.getParameter("studentId");

    if (
        studentIdParameter == null
        || studentIdParameter.trim().isEmpty()
    ) {

        errorMessage =
            "No student record was selected.";

    } else {

        try {
            int studentId =
                Integer.parseInt(studentIdParameter);

            String url =
                "jdbc:mysql://localhost:3306/csd430"
                + "?useSSL=false"
                + "&allowPublicKeyRetrieval=true"
                + "&serverTimezone=UTC";

            String dbUser = "root";
            String dbPassword =
                "addimae69";

            String sql =
                "SELECT id, first_name, last_name, "
                + "email, course, grade "
                + "FROM students "
                + "WHERE id = ?";

            Class.forName("com.mysql.cj.jdbc.Driver");

            try (
                Connection connection =
                    DriverManager.getConnection(
                        url,
                        dbUser,
                        dbPassword
                    );

                PreparedStatement preparedStatement =
                    connection.prepareStatement(sql)
            ) {

                preparedStatement.setInt(
                    1,
                    studentId
                );

                try (
                    ResultSet resultSet =
                        preparedStatement.executeQuery()
                ) {

                    if (resultSet.next()) {

                        student = new StudentBean();

                        student.setId(
                            resultSet.getInt("id")
                        );

                        student.setFirstName(
                            resultSet.getString("first_name")
                        );

                        student.setLastName(
                            resultSet.getString("last_name")
                        );

                        student.setEmail(
                            resultSet.getString("email")
                        );

                        student.setCourse(
                            resultSet.getString("course")
                        );

                        student.setGrade(
                            resultSet.getString("grade")
                        );

                    } else {

                        errorMessage =
                            "The selected student record was not found.";
                    }
                }
            }

        } catch (NumberFormatException exception) {

            errorMessage =
                "The selected student ID was invalid.";

        } catch (Exception exception) {

            errorMessage = exception.getMessage();
        }
    }
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Student Record</title>

    <link rel="stylesheet" href="styles.css">
</head>

<body>

<header>
    <h1>Update Student Record</h1>

    <p>
        Edit the selected student information
    </p>
</header>

<nav>
    <a href="index.jsp">Create and View Records</a>
    <a href="selectStudent.jsp">Update a Record</a>
</nav>

<main class="container">

    <% if (errorMessage != null) { %>

        <div class="error">
            <strong>Error:</strong>
            <%= errorMessage %>
        </div>

        <a
            class="button"
            href="selectStudent.jsp"
        >
            Return to Student Selection
        </a>

    <% } else { %>

        <h2>Edit Student Information</h2>

        <div class="note">
            The ID is the table’s primary key. It is displayed
            below but cannot be changed.
        </div>

        <form
            method="post"
            action="updateStudent.jsp"
        >

            <div class="form-group">

                <label for="studentId">
                    Student ID
                </label>

                <input
                    type="number"
                    id="studentId"
                    name="studentId"
                    value="<%= student.getId() %>"
                    readonly
                >

            </div>

            <div class="form-group">

                <label for="firstName">
                    First Name
                </label>

                <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value="<%= student.getFirstName() %>"
                    maxlength="50"
                    required
                >

            </div>

            <div class="form-group">

                <label for="lastName">
                    Last Name
                </label>

                <input
                    type="text"
                    id="lastName"
                    name="lastName"
                    value="<%= student.getLastName() %>"
                    maxlength="50"
                    required
                >

            </div>

            <div class="form-group">

                <label for="email">
                    Email Address
                </label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<%= student.getEmail() %>"
                    maxlength="100"
                    required
                >

            </div>

            <div class="form-group">

                <label for="course">
                    Course
                </label>

                <input
                    type="text"
                    id="course"
                    name="course"
                    value="<%= student.getCourse() %>"
                    maxlength="50"
                    required
                >

            </div>

            <div class="form-group">

                <label for="grade">
                    Grade
                </label>

                <input
                    type="text"
                    id="grade"
                    name="grade"
                    value="<%= student.getGrade() %>"
                    maxlength="10"
                    required
                >

            </div>

            <button type="submit">
                Save Updated Record
            </button>

        </form>

    <% } %>

</main>

<footer>
    Jordan Dardar | CSD430 Server Side Development
</footer>

</body>
</html>