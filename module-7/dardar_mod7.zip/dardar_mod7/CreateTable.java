import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateTable {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/csd430";
        String user = "root";
        String password = "PUT_YOUR_MYSQL_PASSWORD_HERE";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();

            String sql = "CREATE TABLE IF NOT EXISTS students ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "first_name VARCHAR(50), "
                    + "last_name VARCHAR(50), "
                    + "email VARCHAR(100), "
                    + "course VARCHAR(50), "
                    + "grade VARCHAR(10))";

            statement.executeUpdate(sql);

            System.out.println("The students table was created successfully.");

            statement.close();
            connection.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}