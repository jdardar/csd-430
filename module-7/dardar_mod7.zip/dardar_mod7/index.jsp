<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>CSD430 Module 7.2 CRUD Create</title>
</head>
<body>

<h1>CSD430 Module 7.2 CRUD Create and JavaBeans</h1>

<h2>Student Record Entry Form</h2>

<p>
    This application connects to a MySQL database and allows the user to add a new
    student record. After the record is submitted, all records from the database
    are displayed in an HTML table.
</p>

<form method="post" action="index.jsp">
    <label>First Name:</label>
    <input type="text" name="firstName" required><br><br>

    <label>Last Name:</label>
    <input type="text" name="lastName" required><br><br>

    <label>Email:</label>
    <input type="text" name="email" required><br><br>

    <label>Course:</label>
    <input type="text" name="course" required><br><br>

    <label>Grade:</label>
    <input type="text" name="grade" required><br><br>

    <input type="submit" name="submit" value="Add Student">
</form>

<hr>

<%
    String url = "jdbc:mysql://localhost:3306/csd430";
    String dbUser = "root";
    String dbPassword = "addimae69";

    Connection connection = null;
    PreparedStatement preparedStatement = null;
    Statement statement = null;
    ResultSet resultSet = null;

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        connection = DriverManager.getConnection(url, dbUser, dbPassword);

        if (request.getParameter("submit") != null) {
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String email = request.getParameter("email");
            String course = request.getParameter("course");
            String grade = request.getParameter("grade");

            String insertSql = "INSERT INTO students (first_name, last_name, email, course, grade) VALUES (?, ?, ?, ?, ?)";

            preparedStatement = connection.prepareStatement(insertSql);
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, course);
            preparedStatement.setString(5, grade);

            preparedStatement.executeUpdate();
%>

<p><strong>Record added successfully.</strong></p>

<%
        }
%>

<h2>Current Student Records</h2>

<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email Address</th>
        <th>Course</th>
        <th>Grade</th>
    </tr>

<%
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT * FROM students");

        while (resultSet.next()) {
%>

    <tr>
        <td><%= resultSet.getInt("id") %></td>
        <td><%= resultSet.getString("first_name") %></td>
        <td><%= resultSet.getString("last_name") %></td>
        <td><%= resultSet.getString("email") %></td>
        <td><%= resultSet.getString("course") %></td>
        <td><%= resultSet.getString("grade") %></td>
    </tr>

<%
        }

    } catch (Exception e) {
%>

<p><strong>Error:</strong> <%= e.getMessage() %></p>

<%
    } finally {
        if (resultSet != null) resultSet.close();
        if (statement != null) statement.close();
        if (preparedStatement != null) preparedStatement.close();
        if (connection != null) connection.close();
    }
%>

</table>

</body>
</html>