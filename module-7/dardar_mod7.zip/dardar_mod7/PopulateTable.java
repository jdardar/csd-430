import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class PopulateTable {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/csd430";
        String user = "root";
        String password = "PUT_YOUR_MYSQL_PASSWORD_HERE";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection connection = DriverManager.getConnection(url, user, password);

            String sql = "INSERT INTO students (first_name, last_name, email, course, grade) VALUES (?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, "Jordan");
            preparedStatement.setString(2, "Dardar");
            preparedStatement.setString(3, "jordan@email.com");
            preparedStatement.setString(4, "CSD430");
            preparedStatement.setString(5, "A");
            preparedStatement.executeUpdate();

            preparedStatement.setString(1, "John");
            preparedStatement.setString(2, "Smith");
            preparedStatement.setString(3, "john@email.com");
            preparedStatement.setString(4, "CSD430");
            preparedStatement.setString(5, "B");
            preparedStatement.executeUpdate();

            preparedStatement.setString(1, "Sarah");
            preparedStatement.setString(2, "Johnson");
            preparedStatement.setString(3, "sarah@email.com");
            preparedStatement.setString(4, "CSD430");
            preparedStatement.setString(5, "A");
            preparedStatement.executeUpdate();

            preparedStatement.setString(1, "Mike");
            preparedStatement.setString(2, "Brown");
            preparedStatement.setString(3, "mike@email.com");
            preparedStatement.setString(4, "CSD430");
            preparedStatement.setString(5, "C");
            preparedStatement.executeUpdate();

            preparedStatement.setString(1, "Emily");
            preparedStatement.setString(2, "Davis");
            preparedStatement.setString(3, "emily@email.com");
            preparedStatement.setString(4, "CSD430");
            preparedStatement.setString(5, "B");
            preparedStatement.executeUpdate();

            System.out.println("The students table was populated successfully.");

            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}