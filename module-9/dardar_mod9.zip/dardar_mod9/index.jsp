<%@ page import="java.sql.*" %>
<%@ page import="com.dardar.StudentBean" %>

<%
    /*
     * index.jsp
     *
     * Displays the create form, inserts a new student record,
     * and displays every current student record.
     */

    request.setCharacterEncoding("UTF-8");

    String url =
        "jdbc:mysql://localhost:3306/csd430"
        + "?useSSL=false"
        + "&allowPublicKeyRetrieval=true"
        + "&serverTimezone=UTC";

    String dbUser = "root";
    String dbPassword = "addimae69";

    String successMessage = null;
    String errorMessage = null;

    if ("POST".equalsIgnoreCase(request.getMethod())) {

        StudentBean student = new StudentBean();

        student.setFirstName(
            request.getParameter("firstName")
        );

        student.setLastName(
            request.getParameter("lastName")
        );

        student.setEmail(
            request.getParameter("email")
        );

        student.setCourse(
            request.getParameter("course")
        );

        student.setGrade(
            request.getParameter("grade")
        );

        String insertSql =
            "INSERT INTO students "
            + "(first_name, last_name, email, course, grade) "
            + "VALUES (?, ?, ?, ?, ?)";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (
                Connection connection =
                    DriverManager.getConnection(
                        url,
                        dbUser,
                        dbPassword
                    );

                PreparedStatement preparedStatement =
                    connection.prepareStatement(insertSql)
            ) {
                preparedStatement.setString(
                    1,
                    student.getFirstName()
                );

                preparedStatement.setString(
                    2,
                    student.getLastName()
                );

                preparedStatement.setString(
                    3,
                    student.getEmail()
                );

                preparedStatement.setString(
                    4,
                    student.getCourse()
                );

                preparedStatement.setString(
                    5,
                    student.getGrade()
                );

                int rowsInserted =
                    preparedStatement.executeUpdate();

                if (rowsInserted == 1) {
                    successMessage =
                        "The student record was added successfully.";
                } else {
                    errorMessage =
                        "The student record was not added.";
                }
            }

        } catch (Exception exception) {
            errorMessage = exception.getMessage();
        }
    }

    Connection displayConnection = null;
    PreparedStatement displayStatement = null;
    ResultSet resultSet = null;

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        displayConnection =
            DriverManager.getConnection(
                url,
                dbUser,
                dbPassword
            );

        String selectSql =
            "SELECT id, first_name, last_name, "
            + "email, course, grade "
            + "FROM students "
            + "ORDER BY id";

        displayStatement =
            displayConnection.prepareStatement(selectSql);

        resultSet =
            displayStatement.executeQuery();

    } catch (Exception exception) {

        if (errorMessage == null) {
            errorMessage = exception.getMessage();
        }
    }
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>CSD430 Module 9</title>

    <link rel="stylesheet" href="styles.css">
</head>

<body>

<header>
    <h1>CSD430 Module 9</h1>

    <p>
        CRUD Create, Update, Delete, JDBC, and JavaBeans
    </p>
</header>

<nav>
    <a href="index.jsp">Create and View Records</a>
    <a href="selectStudent.jsp">Update a Record</a>
    <a href="deleteStudent.jsp">Delete a Record</a>
</nav>

<main class="container">

    <h2>Student Record Entry Form</h2>

    <p>
        Enter a new student record below. After the record is
        submitted, it will be stored in the MySQL database and
        displayed in the student records table.
    </p>

    <% if (successMessage != null) { %>

        <div class="success">
            <%= successMessage %>
        </div>

    <% } %>

    <% if (errorMessage != null) { %>

        <div class="error">
            <strong>Error:</strong>
            <%= errorMessage %>
        </div>

    <% } %>

    <form method="post" action="index.jsp">

        <div class="form-group">
            <label for="firstName">
                First Name
            </label>

            <input
                type="text"
                id="firstName"
                name="firstName"
                maxlength="50"
                required
            >
        </div>

        <div class="form-group">
            <label for="lastName">
                Last Name
            </label>

            <input
                type="text"
                id="lastName"
                name="lastName"
                maxlength="50"
                required
            >
        </div>

        <div class="form-group">
            <label for="email">
                Email Address
            </label>

            <input
                type="email"
                id="email"
                name="email"
                maxlength="100"
                required
            >
        </div>

        <div class="form-group">
            <label for="course">
                Course
            </label>

            <input
                type="text"
                id="course"
                name="course"
                maxlength="50"
                required
            >
        </div>

        <div class="form-group">
            <label for="grade">
                Grade
            </label>

            <input
                type="text"
                id="grade"
                name="grade"
                maxlength="10"
                required
            >
        </div>

        <button type="submit">
            Add Student
        </button>

    </form>

    <hr>

    <h2>Current Student Records</h2>

    <div class="table-wrapper">

        <table>

            <thead>
                <tr>
                    <th>ID<br>INT</th>
                    <th>First Name<br>VARCHAR(50)</th>
                    <th>Last Name<br>VARCHAR(50)</th>
                    <th>Email<br>VARCHAR(100)</th>
                    <th>Course<br>VARCHAR(50)</th>
                    <th>Grade<br>VARCHAR(10)</th>
                </tr>
            </thead>

            <tbody>

                <% if (resultSet != null) { %>

                    <% while (resultSet.next()) { %>

                        <tr>
                            <td>
                                <%= resultSet.getInt("id") %>
                            </td>

                            <td>
                                <%= resultSet.getString("first_name") %>
                            </td>

                            <td>
                                <%= resultSet.getString("last_name") %>
                            </td>

                            <td>
                                <%= resultSet.getString("email") %>
                            </td>

                            <td>
                                <%= resultSet.getString("course") %>
                            </td>

                            <td>
                                <%= resultSet.getString("grade") %>
                            </td>
                        </tr>

                    <% } %>

                <% } %>

            </tbody>

        </table>

    </div>

</main>

<footer>
    Jordan Dardar | CSD430 Server Side Development
</footer>

</body>
</html>

<%
    if (resultSet != null) {
        try {
            resultSet.close();
        } catch (SQLException ignored) {
        }
    }

    if (displayStatement != null) {
        try {
            displayStatement.close();
        } catch (SQLException ignored) {
        }
    }

    if (displayConnection != null) {
        try {
            displayConnection.close();
        } catch (SQLException ignored) {
        }
    }
%>