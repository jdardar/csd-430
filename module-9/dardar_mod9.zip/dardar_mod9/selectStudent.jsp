<%@ page import="java.sql.*" %>

<%
    /*
     * selectStudent.jsp
     *
     * Retrieves student primary-key values and places
     * them into an HTML dropdown menu.
     */

    String url =
        "jdbc:mysql://localhost:3306/csd430"
        + "?useSSL=false"
        + "&allowPublicKeyRetrieval=true"
        + "&serverTimezone=UTC";

    String dbUser = "root";
    String dbPassword = "addimae69";

    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    String errorMessage = null;

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        connection =
            DriverManager.getConnection(
                url,
                dbUser,
                dbPassword
            );

        String sql =
            "SELECT id, first_name, last_name "
            + "FROM students "
            + "ORDER BY id";

        preparedStatement =
            connection.prepareStatement(sql);

        resultSet =
            preparedStatement.executeQuery();

    } catch (Exception exception) {
        errorMessage = exception.getMessage();
    }
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Select Student Record</title>

    <link rel="stylesheet" href="styles.css">
</head>

<body>

<header>
    <h1>Select a Student Record</h1>

    <p>
        Choose the database record you want to update
    </p>
</header>

<nav>
    <a href="index.jsp">Create and View Records</a>
    <a href="selectStudent.jsp">Update a Record</a>
    <a href="deleteStudent.jsp">Delete a Record</a>
</nav>

<main class="container">

    <h2>Student Record Selection</h2>

    <div class="note">
        The numeric ID shown in each option is the primary-key
        value stored in the students table.
    </div>

    <% if (errorMessage != null) { %>

        <div class="error">
            <strong>Database error:</strong>
            <%= errorMessage %>
        </div>

    <% } else { %>

        <form
            method="get"
            action="editStudent.jsp"
        >

            <div class="form-group">

                <label for="studentId">
                    Select a Student
                </label>

                <select
                    id="studentId"
                    name="studentId"
                    required
                >

                    <option value="">
                        Choose a student record
                    </option>

                    <% while (resultSet.next()) { %>

                        <option
                            value="<%= resultSet.getInt("id") %>"
                        >
                            ID <%= resultSet.getInt("id") %>
                            -
                            <%= resultSet.getString("first_name") %>
                            <%= resultSet.getString("last_name") %>
                        </option>

                    <% } %>

                </select>

            </div>

            <button type="submit">
                Open Update Form
            </button>

        </form>

    <% } %>

</main>

<footer>
    Jordan Dardar | CSD430 Server Side Development
</footer>

</body>
</html>

<%
    if (resultSet != null) {
        try {
            resultSet.close();
        } catch (SQLException ignored) {
        }
    }

    if (preparedStatement != null) {
        try {
            preparedStatement.close();
        } catch (SQLException ignored) {
        }
    }

    if (connection != null) {
        try {
            connection.close();
        } catch (SQLException ignored) {
        }
    }
%>