<%@ page import="java.sql.*" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.List" %>
<%@ page import="com.dardar.StudentBean" %>

<%
    /*
     * deleteStudent.jsp
     *
     * Module 9 CRUD-DELETE page. The page displays every student record,
     * places all remaining primary-key values in an HTML select list,
     * deletes the selected record, and then reloads the remaining records.
     * If all records are removed, the table header remains visible.
     */

    request.setCharacterEncoding("UTF-8");

    String url =
        "jdbc:mysql://localhost:3306/csd430"
        + "?useSSL=false"
        + "&allowPublicKeyRetrieval=true"
        + "&serverTimezone=UTC";

    String dbUser = "root";
    String dbPassword = "addimae69";

    String successMessage = null;
    String errorMessage = null;
    List<StudentBean> students = new ArrayList<StudentBean>();

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        try (Connection connection =
                DriverManager.getConnection(url, dbUser, dbPassword)) {

            if ("POST".equalsIgnoreCase(request.getMethod())) {
                String studentIdParameter = request.getParameter("studentId");

                if (studentIdParameter == null
                        || studentIdParameter.trim().isEmpty()) {
                    errorMessage = "Select a student ID before deleting a record.";
                } else {
                    int studentId = Integer.parseInt(studentIdParameter);
                    String deleteSql = "DELETE FROM students WHERE id = ?";

                    try (PreparedStatement deleteStatement =
                            connection.prepareStatement(deleteSql)) {
                        deleteStatement.setInt(1, studentId);
                        int rowsDeleted = deleteStatement.executeUpdate();

                        if (rowsDeleted == 1) {
                            successMessage =
                                "Student record ID " + studentId
                                + " was deleted successfully.";
                        } else {
                            errorMessage =
                                "No student record was found for ID "
                                + studentId + ".";
                        }
                    }
                }
            }

            String selectSql =
                "SELECT id, first_name, last_name, email, course, grade "
                + "FROM students ORDER BY id";

            try (PreparedStatement selectStatement =
                    connection.prepareStatement(selectSql);
                 ResultSet resultSet = selectStatement.executeQuery()) {

                while (resultSet.next()) {
                    StudentBean student = new StudentBean();
                    student.setId(resultSet.getInt("id"));
                    student.setFirstName(resultSet.getString("first_name"));
                    student.setLastName(resultSet.getString("last_name"));
                    student.setEmail(resultSet.getString("email"));
                    student.setCourse(resultSet.getString("course"));
                    student.setGrade(resultSet.getString("grade"));
                    students.add(student);
                }
            }
        }
    } catch (NumberFormatException exception) {
        errorMessage = "The selected student ID was invalid.";
    } catch (Exception exception) {
        errorMessage = exception.getMessage();
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSD430 Module 9 - Delete Student Records</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>
    <h1>CSD430 Module 9</h1>
    <p>CRUD Delete, JDBC, and JavaBeans</p>
</header>

<nav>
    <a href="index.jsp">Create and View Records</a>
    <a href="selectStudent.jsp">Update a Record</a>
    <a href="deleteStudent.jsp">Delete a Record</a>
</nav>

<main class="container">
    <h2>Delete a Student Record</h2>

    <p>
        Select a primary-key ID from the list below. Submitting the form
        permanently deletes that record from the MySQL students table.
        The table and dropdown then refresh to show only remaining records.
    </p>

    <% if (successMessage != null) { %>
        <div class="success"><%= successMessage %></div>
    <% } %>

    <% if (errorMessage != null) { %>
        <div class="error"><strong>Error:</strong> <%= errorMessage %></div>
    <% } %>

    <% if (!students.isEmpty()) { %>
        <form method="post" action="deleteStudent.jsp"
              onsubmit="return confirm('Delete the selected student record?');">
            <div class="form-group">
                <label for="studentId">Student Primary-Key ID</label>
                <select id="studentId" name="studentId" required>
                    <option value="">Choose a student record</option>
                    <% for (StudentBean student : students) { %>
                        <option value="<%= student.getId() %>">
                            ID <%= student.getId() %> -
                            <%= student.getFirstName() %>
                            <%= student.getLastName() %>
                        </option>
                    <% } %>
                </select>
            </div>
            <button class="danger-button" type="submit">Delete Student</button>
        </form>
    <% } else { %>
        <div class="note">
            No student records remain. The empty table header is displayed below.
            Add another record from the Create and View Records page when needed.
        </div>
    <% } %>

    <hr>

    <h2>Remaining Student Records</h2>
    <p>
        Database table: <strong>students</strong>. The six displayed fields are
        the primary key, first name, last name, email address, course, and grade.
    </p>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID<br>INT PRIMARY KEY</th>
                    <th>First Name<br>VARCHAR(50)</th>
                    <th>Last Name<br>VARCHAR(50)</th>
                    <th>Email<br>VARCHAR(100)</th>
                    <th>Course<br>VARCHAR(50)</th>
                    <th>Grade<br>VARCHAR(10)</th>
                </tr>
            </thead>
            <tbody>
                <% for (StudentBean student : students) { %>
                    <tr>
                        <td><%= student.getId() %></td>
                        <td><%= student.getFirstName() %></td>
                        <td><%= student.getLastName() %></td>
                        <td><%= student.getEmail() %></td>
                        <td><%= student.getCourse() %></td>
                        <td><%= student.getGrade() %></td>
                    </tr>
                <% } %>
            </tbody>
        </table>
    </div>
</main>

<footer>
    Jordan Dardar | CSD430 Server Side Development | Module 9.2
</footer>

</body>
</html>
